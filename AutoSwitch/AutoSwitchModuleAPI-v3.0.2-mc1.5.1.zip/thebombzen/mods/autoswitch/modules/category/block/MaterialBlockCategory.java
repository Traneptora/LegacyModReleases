package thebombzen.mods.autoswitch.modules.category.block;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import net.minecraft.block.material.Material;

import thebombzen.mods.autoswitch.modules.IDMetadataPair;

public class MaterialBlockCategory extends BlockCategory {
	
	protected final Set<Material> materials;
	
	public MaterialBlockCategory(int id, Material... materials){
		super(id);
		this.materials = new HashSet<Material>(Arrays.asList(materials));
	}
	
	public void addMaterial(Material material){
		if (material == null){
			throw new NullPointerException();
		}
		materials.add(material);
	}
	
	protected boolean isBlockCalculatedInCategory(IDMetadataPair pair) {
		return materials.contains(pair.getBlock().blockMaterial);
	}

}
