package thebombzen.mods.autoswitch.modules;

public interface ASModule {
	
}
