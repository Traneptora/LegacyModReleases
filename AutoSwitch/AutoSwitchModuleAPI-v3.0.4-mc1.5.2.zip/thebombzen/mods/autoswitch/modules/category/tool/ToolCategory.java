package thebombzen.mods.autoswitch.modules.category.tool;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import thebombzen.mods.autoswitch.modules.ASVanillaModule;
import thebombzen.mods.autoswitch.modules.IDMetadataPair;
import thebombzen.mods.autoswitch.modules.category.block.BlockCategory;

public abstract class ToolCategory {
	
	private static final Map<Integer, ToolCategory> toolCategoriesMap = new HashMap<Integer, ToolCategory>();

	private final Set<Integer> definedToolsInCategory = new HashSet<Integer>();
	private final Set<Integer> definedToolsNotInCategory = new HashSet<Integer>();
	private final Map<BlockCategory, Float> strongBlockCategories = new HashMap<BlockCategory, Float>();
	private final Set<BlockCategory> notStrongBlockCategories = new HashSet<BlockCategory>();
	private final int id;
	
	public ToolCategory(int id){
		this.id = id;
		toolCategoriesMap.put(id, this);
	}
	
	public int getCategoryID() {
		return id;
	}
	
	public static ToolCategory getCategoryByID(int id){
		return toolCategoriesMap.get(id);
	}
	
	public static Map<Integer, ToolCategory> getToolCategoriesList(){
		return Collections.unmodifiableMap(toolCategoriesMap);
	}
	
	public static ToolCategory getCategoryByShiftedIndex(int shiftedIndex){
		for (ToolCategory category : toolCategoriesMap.values()){
			if (category.isToolInCategory(shiftedIndex)){
				return category;
			}
		}
		return null;
	}
	
	public void addToolToCategory(int shiftedIndex){
		definedToolsInCategory.add(shiftedIndex);
	}
	
	public void makeSureToolIsNotInCategory(int shiftedIndex){
		definedToolsNotInCategory.add(shiftedIndex);
	}

	public void addStrongBlockCategory(BlockCategory category, float strength){
		if (category == null){
			throw new NullPointerException();
		}
		strongBlockCategories.put(category, strength);
	}
	
	public void addNotStrongBlockCategory(BlockCategory category){
		if (category == null){
			throw new NullPointerException();
		}
		notStrongBlockCategories.add(category);
	}
	
	public final boolean isToolInCategory(int shiftedIndex){
		if (definedToolsNotInCategory.contains(shiftedIndex)){
			return false;
		}
		if (definedToolsInCategory.contains(shiftedIndex)){
			return true;
		}
		return isToolCalculatedInCategory(shiftedIndex);
	}
	
	public abstract boolean isToolCalculatedInCategory(int shiftedIndex);

	public float getStrengthVsBlockCategory(int shiftedIndex, BlockCategory category){
		if (!isToolInCategory(shiftedIndex)){
			throw new IllegalArgumentException("Tool must be in category!");
		}
		if (notStrongBlockCategories.contains(category)){
			return -2.0F;
		}
		if (strongBlockCategories.containsKey(category)){
			return strongBlockCategories.get(category);
		}
		return -1.0F;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ToolCategory other = (ToolCategory) obj;
		if (id != other.id)
			return false;
		return true;
	}

}
