package thebombzen.mods.autoswitch.modules.category.tool;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import net.minecraft.item.Item;

public class ClassToolCategory extends ToolCategory {
	
	protected final Set<Class<?>> toolClasses;
	protected final boolean allowSubClasses;
	
	public ClassToolCategory(int id, boolean allowSubClasses, Class<?>... classes) {
		super(id);
		this.allowSubClasses = allowSubClasses;
		toolClasses = new HashSet<Class<?>>(Arrays.asList(classes));
	}
	
	public boolean isToolCalculatedInCategory(int shiftedIndex){
		Item item = Item.itemsList[shiftedIndex];
		if (item == null){
			return false;
		}
		for (Class<?> clazz : toolClasses){
			if (allowSubClasses){
				if (clazz.isAssignableFrom(item.getClass())){
					return true;
				}
			} else {
				if (clazz.equals(item.getClass())){
					return true;
				}
			}
		}
		return false;
	}
	
}
