package thebombzen.mods.autoswitch.modules.category.tool;

import thebombzen.mods.autoswitch.modules.category.block.BlockCategory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemTool;

public class ItemToolClassToolCategory extends ClassToolCategory {

	public ItemToolClassToolCategory(int id, boolean allowSubClasses, Class<? extends ItemTool>... classes) {
		super(id, allowSubClasses, classes);
	}
	
	@Override
	public float getStrengthVsBlockCategory(int shiftedIndex, BlockCategory category){
		float parentStrength = super.getStrengthVsBlockCategory(shiftedIndex, category);
		if (parentStrength <= 0.0F){
			return parentStrength;
		}
		ItemTool tool = (ItemTool)Item.itemsList[shiftedIndex];
		return tool.efficiencyOnProperMaterial;
	}

}
