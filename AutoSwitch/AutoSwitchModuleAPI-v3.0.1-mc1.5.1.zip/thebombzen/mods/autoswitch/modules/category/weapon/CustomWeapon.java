package thebombzen.mods.autoswitch.modules.category.weapon;

import java.util.HashMap;
import java.util.Map;

import net.minecraft.entity.Entity;

public abstract class CustomWeapon {
	private static final Map<Integer, CustomWeapon> customWeaponsMap = new HashMap<Integer, CustomWeapon>();
	
	private int shiftedIndex;
	
	public CustomWeapon(int shiftedIndex){
		this.shiftedIndex = shiftedIndex;
		customWeaponsMap.put(shiftedIndex, this);
	}
	
	public static CustomWeapon getCustomWeaponByShiftedIndex(int shiftedIndex){
		if (customWeaponsMap.containsKey(shiftedIndex)){
			return customWeaponsMap.get(shiftedIndex);
		}
		return null;
	}
	
	public int getShiftedIndex(){
		return shiftedIndex;
	}
	
	public abstract int getDamageVsEntity(Entity entity);
	
}
