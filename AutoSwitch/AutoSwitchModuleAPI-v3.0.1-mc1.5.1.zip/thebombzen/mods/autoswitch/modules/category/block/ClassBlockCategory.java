package thebombzen.mods.autoswitch.modules.category.block;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import net.minecraft.block.Block;
import thebombzen.mods.autoswitch.modules.IDMetadataPair;

public class ClassBlockCategory extends BlockCategory {
	protected final Set<Class<?>> classes;
	
	public ClassBlockCategory(int id, Class<?>... classes){
		super(id);
		this.classes = new HashSet<Class<?>>(Arrays.asList(classes));
	}
	
	public void addClass(Class<?> clazz){
		if (clazz == null){
			throw new NullPointerException();
		}
		classes.add(clazz);
	}
	
	protected boolean isBlockCalculatedInCategory(IDMetadataPair pair){
		for (Class<?> clazz : classes){
			if (clazz.isAssignableFrom(pair.getBlock().getClass())){
				return true;
			}
		}
		return false;
	}
}
