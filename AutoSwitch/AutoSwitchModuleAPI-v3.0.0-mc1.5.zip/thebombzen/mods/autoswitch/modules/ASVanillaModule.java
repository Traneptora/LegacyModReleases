package thebombzen.mods.autoswitch.modules;

import net.minecraft.block.BlockCrops;
import net.minecraft.block.BlockVine;
import net.minecraft.block.material.Material;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemHoe;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemShears;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemSword;
import thebombzen.mods.autoswitch.modules.category.block.BlockCategory;
import thebombzen.mods.autoswitch.modules.category.block.ClassBlockCategory;
import thebombzen.mods.autoswitch.modules.category.block.MaterialBlockCategory;
import thebombzen.mods.autoswitch.modules.category.tool.ClassToolCategory;
import thebombzen.mods.autoswitch.modules.category.tool.ItemToolClassToolCategory;
import thebombzen.mods.autoswitch.modules.category.tool.ToolCategory;
import cpw.mods.fml.common.Mod;

@Mod(modid="ASVanillaModule", name="AutoSwitch Vanilla Module", version="See AutoSwitch Version", dependencies="required-after:AutoSwitch")
public class ASVanillaModule implements ASModule {
	
	public static final BlockCategory wood = new MaterialBlockCategory(0, Material.wood);
	public static final BlockCategory rock = new MaterialBlockCategory(1, Material.rock);
	public static final BlockCategory dirt = new MaterialBlockCategory(2, Material.grass, Material.ground);
	public static final BlockCategory crops = new ClassBlockCategory(3, BlockCrops.class);
	public static final BlockCategory iron = new MaterialBlockCategory(4, Material.iron, Material.anvil);
	public static final BlockCategory clay = new MaterialBlockCategory(5, Material.clay);
	public static final BlockCategory sand = new MaterialBlockCategory(6, Material.sand);
	public static final BlockCategory wool = new MaterialBlockCategory(7, Material.cloth);
	public static final BlockCategory snow = new MaterialBlockCategory(8, Material.craftedSnow, Material.snow);
	public static final BlockCategory web = new MaterialBlockCategory(9, Material.web);
	public static final BlockCategory leaves = new MaterialBlockCategory(10, Material.leaves);
	public static final BlockCategory vine = new ClassBlockCategory(11, BlockVine.class);
	public static final BlockCategory ice = new MaterialBlockCategory(12, Material.ice);
	
	public static final ToolCategory pickaxe = new ItemToolClassToolCategory(0, true, ItemPickaxe.class);
	public static final ToolCategory axe = new ItemToolClassToolCategory(1, true, ItemAxe.class);
	public static final ToolCategory shovel = new ItemToolClassToolCategory(2, true, ItemSpade.class);
	public static final ToolCategory shears = new ClassToolCategory(3, true, ItemShears.class);
	public static final ToolCategory sword = new ClassToolCategory(4, true, ItemSword.class);
	public static final ToolCategory hoe = new ClassToolCategory(5, true, ItemHoe.class);
	
	static {
		pickaxe.addStrongBlockCategory(ice, 8F);
		pickaxe.addStrongBlockCategory(iron, 8F);
		pickaxe.addStrongBlockCategory(rock, 8F);
		axe.addStrongBlockCategory(wood, 8F);
		axe.addStrongBlockCategory(vine, 8F);
		shovel.addStrongBlockCategory(clay, 8F);
		shovel.addStrongBlockCategory(dirt, 8F);
		shovel.addStrongBlockCategory(sand, 8F);
		shovel.addStrongBlockCategory(snow, 8F);
		shears.addStrongBlockCategory(leaves, 15F);
		shears.addStrongBlockCategory(vine, 1F);
		shears.addStrongBlockCategory(web, 15F);
		shears.addStrongBlockCategory(wool, 5F);
		sword.addStrongBlockCategory(web, 15F);
		sword.addStrongBlockCategory(vine, 1.5F);
		sword.addStrongBlockCategory(leaves, 1.5F);
		hoe.addStrongBlockCategory(crops, 8F);
	}
}
