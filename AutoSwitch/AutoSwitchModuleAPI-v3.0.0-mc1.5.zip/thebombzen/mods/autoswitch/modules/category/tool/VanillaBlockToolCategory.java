package thebombzen.mods.autoswitch.modules.category.tool;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

import thebombzen.mods.autoswitch.modules.IDMetadataPair;

public class VanillaBlockToolCategory extends ToolCategory {
	protected final Set<IDMetadataPair> effectiveVanillaBlocks = new HashSet<IDMetadataPair>();
	protected final Set<IDMetadataPair> ineffectiveVanillaBlocks = new HashSet<IDMetadataPair>();
	
	public VanillaBlockToolCategory(int id, Collection<? extends IDMetadataPair> effectiveVanillaBlocks, Collection<? extends IDMetadataPair> ineffectiveVanillaBlocks){
		super(id);
		for (IDMetadataPair pair : effectiveVanillaBlocks){
			this.addEffectiveVanillaBlock(pair);
		}
		for (IDMetadataPair pair : ineffectiveVanillaBlocks){
			this.addIneffectiveVanillaBlock(pair);
		}
	}
	
	public void addEffectiveVanillaBlock(IDMetadataPair pair){
		if (pair == null){
			throw new NullPointerException();
		}
		if (!pair.isBlock()){
			throw new IllegalArgumentException("IDMetadataPair is not a block.");
		}
		effectiveVanillaBlocks.add(pair);
	}
	
	public void addIneffectiveVanillaBlock(IDMetadataPair pair){
		if (pair == null){
			throw new NullPointerException();
		}
		if (!pair.isBlock()){
			throw new IllegalArgumentException("IDMetadataPair is not a block.");
		}
		ineffectiveVanillaBlocks.add(pair);
	}
	
	public boolean isToolCalculatedInCategory(int shiftedIndex){
		if (effectiveVanillaBlocks.size() == 0 && ineffectiveVanillaBlocks.size() == 0){
			return false;
		}
		Item item = Item.itemsList[shiftedIndex];
		ItemStack stack = new ItemStack(item);
		for (IDMetadataPair pair : effectiveVanillaBlocks){
			if (item.getStrVsBlock(stack, pair.getBlock(), pair.getDamageValue()) == 1.0F){
				return false;
			}
		}
		for (IDMetadataPair pair : ineffectiveVanillaBlocks){
			if (item.getStrVsBlock(stack, pair.getBlock(), pair.getDamageValue()) > 1.0F){
				return false;
			}
		}
		return true;
	}
	
}
