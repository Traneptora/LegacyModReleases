package thebombzen.mods.autoswitch.modules.category.block;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import thebombzen.mods.autoswitch.modules.IDMetadataPair;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class VanillaToolBlockCategory extends BlockCategory {
	
	protected final Set<Integer> effectiveVanillaTools;
	protected final Set<Integer> ineffectiveVanillaTools;
	
	public VanillaToolBlockCategory(int id, Collection<? extends Integer> effectiveVanillaTools, Collection<? extends Integer> ineffectiveVanillaTools){
		super(id);
		this.effectiveVanillaTools = new HashSet<Integer>(effectiveVanillaTools);
		this.ineffectiveVanillaTools = new HashSet<Integer>(ineffectiveVanillaTools);
	}
	
	public void addEffectiveVanillaTool(int shiftedIndex){
		effectiveVanillaTools.add(shiftedIndex);
	}
	
	public void addIneffectiveVanillaTool(int shiftedIndex){
		ineffectiveVanillaTools.add(shiftedIndex);
	}
	
	protected boolean isBlockCalculatedInCategory(IDMetadataPair pair){
		if (effectiveVanillaTools.size() == 0 && ineffectiveVanillaTools.size() == 0){
			return false;
		}
		for (int shiftedIndex : effectiveVanillaTools){
			if(Item.itemsList[shiftedIndex].getStrVsBlock(new ItemStack(Item.itemsList[shiftedIndex]), pair.getBlock(), pair.getDamageValue()) == 1.0F){
				return false;
			}
		}
		for (int shiftedIndex : ineffectiveVanillaTools){
			if(Item.itemsList[shiftedIndex].getStrVsBlock(new ItemStack(Item.itemsList[shiftedIndex]), pair.getBlock(), pair.getDamageValue()) > 1.0F){
				return false;
			}
		}
		return true;
	}
	
}
