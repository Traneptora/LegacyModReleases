package thebombzen.mods.autoswitch.modules.category.block;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import thebombzen.mods.autoswitch.modules.IDMetadataPair;

public abstract class BlockCategory {
	
	private static final Map<Integer, BlockCategory> blockCategoriesMap = new HashMap<Integer, BlockCategory>();
	
	private Set<IDMetadataPair> definedBlocksInCategory = new HashSet<IDMetadataPair>();
	private Set<IDMetadataPair> definedBlocksNotInCategory = new HashSet<IDMetadataPair>();
	private final int id;
	
	public BlockCategory(int id){
		this.id = id;
		blockCategoriesMap.put(id, this);
	}
	
	public int getCategoryID() {
		return id;
	}
	
	public static BlockCategory getCategoryByID(int id){
		return blockCategoriesMap.get(id);
	}
	
	public static Map<Integer, BlockCategory> getBlocksCategoryList(){
		return Collections.unmodifiableMap(blockCategoriesMap);
	}
	
	public static BlockCategory getCategoryByBlock(IDMetadataPair block){
		for (BlockCategory category : blockCategoriesMap.values()){
			if (category.isBlockInCategory(block)){
				return category;
			}
		}
		return null;
	}
	
	public void addBlockToCategory(IDMetadataPair block){
		if (block == null){
			throw new NullPointerException();
		}
		definedBlocksInCategory.add(block);
	}
	
	public void addAllBlocksWithIDToCategory(int blockID){
		definedBlocksInCategory.add(new IDMetadataPair(blockID, -1));
	}
	
	public void makeSureBlockIsNotInCategory(IDMetadataPair block){
		if (block == null){
			throw new NullPointerException();
		}
		definedBlocksNotInCategory.add(block);
	}
	
	public void makeSureAllBlocksWithIDNotInCategory(int blockID){
		definedBlocksNotInCategory.add(new IDMetadataPair(blockID, -1));
	}
	
	protected abstract boolean isBlockCalculatedInCategory(IDMetadataPair block);
	
	public final boolean isBlockInCategory(IDMetadataPair block){
		if (block == null){
			return false;
		}
		for (IDMetadataPair pair : definedBlocksNotInCategory){
			if (pair.includes(block)){
				return false;
			}
		}
		for (IDMetadataPair pair : definedBlocksInCategory){
			if (pair.includes(block)){
				return true;
			}
		}
		return this.isBlockCalculatedInCategory(block);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BlockCategory other = (BlockCategory) obj;
		if (id != other.id)
			return false;
		return true;
	}
	
}
